package com.example.project;

import android.app.Application;

import tendroid.model.TenGame;

public class TheApplication extends Application {

    int gameScore = 0;
    int tabWidth = 5;
    int caseValueToWin = 11;



    @Override
    public void onCreate() {
        super.onCreate();
    }

    //Initialisation du tableau
    public int[] generateTab(){
       int[] tabTmp = new int[tabWidth * tabWidth];

        for(int i=0; i < tabWidth * tabWidth; i++){
            tabTmp[i] = (int)(Math.random() * 4) + 1;
        }
        return tabTmp;
    }

    int[] tab = generateTab();
    TenGame gameParty = new TenGame(tab);
}
