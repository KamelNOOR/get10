package com.example.project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {

    TheApplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        app = (TheApplication)(this.getApplication());
    }


    public void onClickExit(View v) {
        finish();
    }

    public void onClickPlay(View v) {
        Intent playIntent = new Intent(this, PlayActivity.class);
        startActivity(playIntent);
    }

    public void onClickRules(View v) {
        Intent playIntent = new Intent(this, RulesActivity.class);
        startActivity(playIntent);
    }

}
