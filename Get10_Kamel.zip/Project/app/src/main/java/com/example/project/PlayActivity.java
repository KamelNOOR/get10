package com.example.project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Chronometer;
import android.widget.RelativeLayout;


import tendroid.model.TenGame;

public class PlayActivity extends Activity {

    TheApplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        updateTimer();
        app = (TheApplication) getApplicationContext();
        app.tab = app.generateTab();
        app.gameParty = new TenGame(app.tab);

    }

    public void onClickReset(View v){
        app.gameParty = new TenGame();
        app.gameScore = 0;
        Chronometer timerChrono = findViewById(R.id.chronoTimeNumber);
        timerChrono.stop();
        finish();
        startActivity(getIntent());
    }

    public void onClickExit(View v) {
        Chronometer timerChrono = findViewById(R.id.chronoTimeNumber);
        timerChrono.stop();
        finish();
    }

    //Retour accueil
    public void onClickHome(View v){
        Intent mainActivity = new Intent(this, MainActivity.class);
        startActivity(mainActivity);
    }


    //Fonctione Chrono
    protected void updateTimer(){
        Chronometer timerChrono = findViewById(R.id.chronoTimeNumber);
        timerChrono.start();
    }

    //Fonction pour que le jeu s'adapte aux bordures
    public void adaptViews(){

        GameBoard boardSurface = findViewById(R.id.boardSurface);

        RelativeLayout.LayoutParams boardAdapt = new RelativeLayout.LayoutParams(boardSurface.getWidth(),boardSurface.getWidth());
        boardAdapt.addRule(RelativeLayout.BELOW, R.id.layoutScoreTimeNumber);
        boardSurface.setLayoutParams(boardAdapt);

    }
}
