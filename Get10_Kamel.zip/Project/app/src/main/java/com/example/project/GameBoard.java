package com.example.project;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;
import tendroid.model.Position;

public class GameBoard extends SurfaceView implements SurfaceHolder.Callback {

    TheApplication app;
    Context context;
    int tabSQ;
    int CWidth = 0;
    int CHeight = 0;
    com.example.project.Position selectedPosition = new com.example.project.Position(-1,-1);

    public GameBoard(Context context) {
        super(context);
        getHolder().addCallback(this);
        this.context = context;
        app = (TheApplication) (context.getApplicationContext());
        tabSQ = app.tabWidth;

    }

    public GameBoard(Context context, AttributeSet attrs) {

        super(context, attrs);
        getHolder().addCallback(this);
        this.context = context;
        app = (TheApplication) (context.getApplicationContext());
        tabSQ = app.tabWidth;

    }

    @SuppressLint("WrongCall")
    public void reDraw() {

        Canvas c = getHolder().lockCanvas();
        if (c != null) {
            this.onDraw(c);
            getHolder().unlockCanvasAndPost(c);

        }
    }

    public void toastVictoire(){

        Toast.makeText(app.getBaseContext(), "Bravo ! Vous avez reussi ! ", Toast.LENGTH_LONG).show();
    }

    public void toastDefaite(){

        Toast.makeText(app.getBaseContext(), "Perdu ... Tentez encore une fois ! ", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onDraw(Canvas c) {

        boolean win = false;
        boolean lose = true;
        CWidth = c.getWidth();  //Largeur du jeu
        CHeight = c.getHeight(); //Longueur du jeu
        Paint p = new Paint();

        //Verification Victoire
        for(int i=0; i < tabSQ ; i++){
            for(int j=0; j < tabSQ; j++) {

                if(app.gameParty.get(new Position(i, j)) == app.caseValueToWin)
                    win = true;

                if(app.gameParty.getGroup(new Position(i, j)).size() > 0)
                    lose = false;
            }
        }

        //Mise en place de la grille
        for(int i=0; i < tabSQ ; i++){
            for(int j=0; j < tabSQ; j++) {

                int rectX = c.getWidth() / tabSQ * i;
                int rectY = c.getHeight() / tabSQ * j;
                int rectW = c.getWidth() / tabSQ;
                int rectH = c.getHeight() / tabSQ;
                int elemSize = c.getWidth() / (tabSQ * 2);

                int elemValue = app.gameParty.get(new Position(i, j));

                int elemXCanvas = c.getWidth() / tabSQ * i + (c.getWidth() - elemSize * tabSQ) / (tabSQ + 2);
                int elemYCanvas = c.getHeight() / tabSQ * j + (c.getHeight() - elemSize * tabSQ) / (tabSQ + 1) + c.getHeight() / tabSQ / 2 - elemSize / 2;

                // Floutter
                if(win || lose)
                    p.setMaskFilter(new BlurMaskFilter(10, BlurMaskFilter.Blur.NORMAL));

                switch (elemValue) {
                    case 1:
                        p.setColor(getResources().getColor(R.color.cellule_1));
                        break;
                    case 2:
                        p.setColor(getResources().getColor(R.color.cellule_2));
                        break;
                    case 3:
                        p.setColor(getResources().getColor(R.color.cellule_3));
                        break;
                    case 4:
                        p.setColor(getResources().getColor(R.color.cellule_4));
                        break;
                    case 5:
                        p.setColor(getResources().getColor(R.color.cellule_5));
                        break;
                    case 6:
                        p.setColor(getResources().getColor(R.color.cellule_6));
                        break;
                    case 7:
                        p.setColor(getResources().getColor(R.color.cellule_7));
                        break;
                    case 8:
                        p.setColor(getResources().getColor(R.color.cellule_8));
                        break;
                    case 9:
                        p.setColor(getResources().getColor(R.color.cellule_9));
                        break;
                    case 10:
                        p.setColor(getResources().getColor(R.color.cellule_10));
                        break;
                }
                c.drawRect(rectX, rectY, rectX + rectW ,rectY + rectH, p);

                p.setTextSize(elemSize);
                p.setColor(Color.WHITE);

                c.drawText("" + elemValue, elemXCanvas , elemYCanvas, p);
                p.setColor(Color.BLACK);
                // Trait separateur cellule
                for( int k=0; k<=5; k++ ) {
                    c.drawLine( 0,k*CWidth/5,CWidth,k*CWidth/5, p );
                    c.drawLine( k*CWidth/5,0,k*CWidth/5,CWidth, p );
                }

                if ( selectedPosition.getX() != -1 && selectedPosition.getY() != -1 ) {
                    p.setStrokeWidth( 5 );
                    p.setStyle( Paint.Style.STROKE );
                    c.drawRect( selectedPosition.getY() * CWidth/5,
                            selectedPosition.getX()* CWidth/5,
                            (selectedPosition.getY()+1) * CWidth/5,
                            (selectedPosition.getX()+1) * CWidth/5,
                            p);
                    p.setStyle( Paint.Style.FILL_AND_STROKE );
                    p.setStrokeWidth( 1 );
                }
            }
        }
        if(win || lose) {

            // On stoppe le chrono
            Chronometer timerChrono = ((Activity)context).findViewById(R.id.chronoTimeNumber);
            timerChrono.stop();

            if(win)
                toastVictoire();
            else
                toastDefaite();

        }

    }

    @Override
    public void surfaceCreated(SurfaceHolder sh) {

        // Adaptation selon la taille de la grille
        PlayActivity playAc = (PlayActivity) context;
        playAc.adaptViews();

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height){

        //Reinitialisation surface
        reDraw();

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

        //Pas de suppression de surface

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int elemXCanvas = (int) event.getY() / (CHeight / tabSQ);
        int elemYCanvas = (int) event.getX() / (CWidth / tabSQ);
        selectedPosition.setX(elemXCanvas);
        selectedPosition.setY(elemYCanvas);

        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                int newScore = 0;
                app.gameParty.transition(new Position(elemYCanvas,elemXCanvas));
                if(app.gameParty.getSelectedGroup() == null) {
                    for(int i = 0; i < tabSQ; i++){
                        for(int j = 0; j < tabSQ; j++){
                            if(app.gameParty.get(new Position(j, i)) == null)
                                newScore++;
                        }
                    }
                    app.gameParty.refill(app.tab);
                }
                reDraw();

                //Mise a jour score
                app.gameScore += newScore;

                TextView tt =((Activity)context).findViewById(R.id.textViewScoreNumber);
                tt.setText("" + app.gameScore);

                return true;
            }
            case MotionEvent.ACTION_UP:{
                reDraw();
                return true;
            }
            default:
                return false;
        }
    }
}